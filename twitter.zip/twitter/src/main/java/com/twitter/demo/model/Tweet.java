package com.twitter.demo.model;

public class Tweet {
	

	private Long userId;
	private User user;
	private String message;
	private String time;
	
	private Integer likes;
	//private List<String> tag;

	public Tweet() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Tweet(Long userId, User user, String message, String time, Integer likes) {
		super();
		this.userId = userId;
		this.user = user;
		this.message = message;
		this.time = time;
		this.likes = likes;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public Integer getLikes() {
		return likes;
	}
	public void setLikes(Integer likes) {
		this.likes = likes;
	}
	
	
	
	
	

}
