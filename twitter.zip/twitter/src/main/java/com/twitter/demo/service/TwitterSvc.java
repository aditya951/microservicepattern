package com.twitter.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.twitter.demo.model.TwitterMSG;
import com.twitter.demo.repository.TwitterRepository;

@Service
public class TwitterSvc {

	@Autowired
	TwitterRepository twitterRepository;

	public TwitterMSG createTwitter(TwitterMSG twitterMsg) {

		return twitterRepository.save(twitterMsg);
	}

	public TwitterMSG updateTwitter(TwitterMSG updateTwitterMsg, String id) {

		TwitterMSG oldTwitterMSG = twitterRepository.findById(id).get();
		TwitterMSG newTwitterMsg = new TwitterMSG(oldTwitterMSG.getId(), oldTwitterMSG.getUserId(),
				oldTwitterMSG.getName(), updateMessage(oldTwitterMSG, updateTwitterMsg),
				oldTwitterMSG.getLocalDateTimeCreated(), updateLikes(oldTwitterMSG, updateTwitterMsg), oldTwitterMSG.getTag(),
				oldTwitterMSG.getReplies());

		//oldTwitterMSG.setMessage(newTwitterMsg.getMessage());

		return twitterRepository.save(newTwitterMsg);
	}

	public String updateMessage(TwitterMSG oldTwitterMSG, TwitterMSG updateTwitterMsg) {

		if (updateTwitterMsg.getMessage() != null) {
			return updateTwitterMsg.getMessage();
		}

		return oldTwitterMSG.getMessage();

	}

	public Integer updateLikes(TwitterMSG oldTwitterMSG, TwitterMSG updateTwitterMsg) {

		if (updateTwitterMsg.getLikes() != null) {
			return updateTwitterMsg.getLikes();
		}

		return oldTwitterMSG.getLikes();

	}
	
	public TwitterMSG replyTwitter(TwitterMSG updateTwitterMsg, String id) {

		TwitterMSG oldTwitterMSG = twitterRepository.findById(id).get();
		List<TwitterMSG> newRepliesLst =new ArrayList<>(oldTwitterMSG.getReplies()) ;
		newRepliesLst.add(updateTwitterMsg);
		oldTwitterMSG.setReplies(newRepliesLst);
		
		//oldTwitterMSG.setMessage(newTwitterMsg.getMessage());

		return twitterRepository.save(oldTwitterMSG);
	}

	public List<TwitterMSG> getAllTweets() {
		List<TwitterMSG> findAll = twitterRepository.findAll();
		return findAll;
	}

	public String deleteTwitter(String id) {
		twitterRepository.deleteById(id);
		return "deleted Successfully" ;
	}

	public List<TwitterMSG> getAllTweetsOfUser(Integer userId) {
		List<TwitterMSG> findByuserId = twitterRepository.findByuserId(userId);
		return findByuserId;
	}
	
//	public List<TwitterMSG> addReply(TwitterMSG oldTwitterMSG, TwitterMSG updateTwitterMsg) {
//
//		 List<TwitterMSG> newRepliesLst =new ArrayList<>(oldTwitterMSG.getReplies()) ;
//		
//		if (updateTwitterMsg.getReplies() != null && (!updateTwitterMsg.getReplies().isEmpty())) {
//			
//			newRepliesLst.add(updateTwitterMsg);
//			return newRepliesLst;
//			
//		}
//
//		return newRepliesLst;
//
//	}

}
