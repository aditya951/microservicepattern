package com.twitter.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.twitter.demo.model.User;
import com.twitter.demo.repository.UserRepository;

@Service
public class UserSvc {
	
	@Autowired
	UserRepository userRepository;

	public User createuser(User user) {
		
		
		return userRepository.save(user);
	}

}
