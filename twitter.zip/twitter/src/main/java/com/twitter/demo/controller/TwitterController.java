package com.twitter.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.twitter.demo.model.TwitterMSG;
import com.twitter.demo.service.TwitterSvc;

@RestController
@RequestMapping("/api/v1.0/tweets")
public class TwitterController {

	@Autowired
	TwitterSvc twittersvc;

	@GetMapping("/all")
	public List<TwitterMSG> getAllTweets() {
		return twittersvc.getAllTweets();
	}
	
	@GetMapping("/{userId}")
	public List<TwitterMSG> getAllTweet( @PathVariable Integer userId) {
		return twittersvc.getAllTweetsOfUser(userId);
	}

	@PostMapping("{userId}/add")
	public TwitterMSG createTwitter(@RequestBody TwitterMSG twittermsg, @PathVariable String userId) {

		twittermsg.setUserId(userId);
		return twittersvc.createTwitter(twittermsg);
	}

	@PutMapping("{userId}/update/{id}")
	public TwitterMSG updateTwitter(@RequestBody TwitterMSG twittermsg, @PathVariable String userId,
			@PathVariable String id) {

		twittermsg.setUserId(userId);
		return twittersvc.updateTwitter(twittermsg, id);
	}

	@PostMapping("{userId}/reply/{id}")
	public TwitterMSG replyTwitter(@RequestBody TwitterMSG twittermsg, @PathVariable String userId,
			@PathVariable String id) {

		twittermsg.setUserId(userId);
		return twittersvc.replyTwitter(twittermsg, id);
	}
	
	@DeleteMapping("{userId}/delete/{id}")
	public String deleteTwitter(@PathVariable Integer userId,@PathVariable String id) {
		
		return twittersvc.deleteTwitter(id);
	}
	

}
