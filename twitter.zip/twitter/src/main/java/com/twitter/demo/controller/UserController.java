package com.twitter.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.twitter.demo.model.User;
import com.twitter.demo.service.UserSvc;

@RestController
@RequestMapping("/api/v1.0/tweets")
public class UserController {
	
	
	@Autowired
	UserSvc usersvc;
	
	@PostMapping("/register")
	public User createTwitter(@RequestBody User user) {

		return usersvc.createuser(user);
	}

}
